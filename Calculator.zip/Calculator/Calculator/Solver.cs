﻿namespace Calculator
{

    internal class Solver
    {
        internal void Accumulate(string v)
        {
            v += v;


        }

        internal string getText()
        {
            throw new NotImplementedException();
        }
    }
}