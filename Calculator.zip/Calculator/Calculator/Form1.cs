using System.Xml;

namespace Calculator
{

    public partial class Form1 : Form
    {
        double Number;
        string operation = "";
        Solver solve = new Solver();
        string skipline = Environment.NewLine;

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "";


        }

        private void button1_Click(object sender, EventArgs e)
        {
            solve.Accumulate("1");
            textBox1.Text = textBox1.Text + "1";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            solve.Accumulate("2");
            textBox1.Text = textBox1.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            solve.Accumulate("3");
            textBox1.Text = textBox1.Text + "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            solve.Accumulate("4");
            textBox1.Text = textBox1.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            solve.Accumulate("5");
            textBox1.Text = textBox1.Text + "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            solve.Accumulate("6");
            textBox1.Text = textBox1.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            solve.Accumulate("7");
            textBox1.Text = textBox1.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            solve.Accumulate("8");
            textBox1.Text = textBox1.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            solve.Accumulate("9");
            textBox1.Text = textBox1.Text + "9";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            solve.Accumulate("0");
            textBox1.Text = textBox1.Text + "0";
        }

        private void button16_Click(object sender, EventArgs e)
        {

            textBox1.Text = textBox1.Text + "+";
            operation = "+";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "-";
            operation = "-";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "*";
            operation = "*";
        }

        private void button15_Click(object sender, EventArgs e)
        {

            textBox1.Text = textBox1.Text + "/";
            operation = "/";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button19_Click(object sender, EventArgs e)
        {
            double nextnum = Number;
            double Result;

            textBox1.Text = textBox1.Text + skipline + "---------------------";
            }
        }

    }
 

