﻿using System;

public interface Isolve
{
    void Accumulate(string s);
    void clear;
    double Solve();
};