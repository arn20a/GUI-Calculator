﻿using System;

class plus : Isolve
{
	
}

public class subtract : Isolve
{

}

public class multiply : Isolve
{

}
public class divide : Isolve
{

}